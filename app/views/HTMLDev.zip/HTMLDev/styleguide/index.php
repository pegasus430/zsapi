<?php include_once('functions.php'); ?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">
  <title>Zippy Style Guide</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#000000">

  <!-- Style Guide Boilerplate Styles -->
  <link rel="stylesheet" href="css/sg-style.css">
  <!--[if lt IE 9]><link rel="stylesheet" href="css/sg-style-old-ie.css"><![endif]-->

  <!-- Replace below stylesheet with your own stylesheet -->
  <link rel="stylesheet" href="../css/style.css">

  <!-- Prisim Syntax Highlighting Styles -->
  <link rel="stylesheet" href="vendor/prisim/prisim.css">

  <!-- Load OUR EXISTING ZIPPY styles -->

  <!-- Bootstrap Core CSS -->
  <link href="css/bootstrap-grid.css"  rel="stylesheet" > 
  <link href="../css/bootstrap-table.css"  rel="stylesheet" > 

  <!-- DROPDOWN PLUGIN CSS -->
  <link href="../css/plugin/jquery.selectBox.css" rel="stylesheet">

  <!-- TOUR PLUGIN CSS -->
  <link href="../css/plugin/hopscotch.css" rel="stylesheet">

  <!-- Datepicker plugin CSS -->
  <link href="../css/plugin/bootstrap-datepicker3.standalone.css" rel="stylesheet">

  <!-- Plugins CSS -->
  <link href="../css/plugin/magnific-popup.css"  rel="stylesheet" > 
  <link href="../css/plugin/cropper.css"  rel="stylesheet" > 
  <link href="../css/plugin/jquery.minicolors.css"  rel="stylesheet" > 

  <!-- DROPDOWN PLUGIN CSS -->
  <link href="../css/plugin/jquery.selectBox.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,700,900' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,700,400italic' rel='stylesheet' type='text/css'>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>
<body>
  <a href="#main" class="sg-visually-hidden sg-visually-hidden-focusable">Skip to main content</a>

  <div id="top" class="sg-header" role="banner">
    <div class="sg-container">
      <h1 class="sg-logo"><img src="../img/logo_zippy.png" alt="">
        <!-- <span class="sg-logo-initials">SG</span> -->
        <!-- <span class="sg-logo-full">ZIPPY</span> --> <em>STYLEGUIDE</em>
      </h1>
      <button type="button" class="sg-nav-toggle">Menu</button>
    </div>
  </div><!--/.sg-header-->

  <div class="sg-wrapper sg-clearfix">
    <div id="nav" class="sg-sidebar" role="navigation">
      <h2 class="sg-h2 sg-subnav-title">Main</h2>
      <ul class="sg-nav-group">
        <li>
          <a href="#sg-colors">Colors</a>
        </li>
        <li>
          <a href="#sg-fontStacks">Fonts</a>
        </li>
      </ul>

      <?php listFilesInFolder('markup'); ?>
    </div><!--/.sg-sidebar-->

    <div id="main" class="sg-main" role="main">
      <div class="sg-container">
        <div class="sg-info">
          <!-- Manually add your UI colors here. -->
          <div class="sg-colors sg-section">
            <h2 id="sg-colors" class="sg-h2">Colors</h2>
            <div class="sg-color-grid">
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #6AA725;"></div>  
                <div class="sg-color-value">#6AA725</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #C40808;"></div>
                <div class="sg-color-value">#C40808</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #4A90E2;"></div>
                <div class="sg-color-value">#4A90E2</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #FF0040;"></div>
                <div class="sg-color-value">#FF0040</div>
              </div>
            </div><!--/.sg-color-grid-->
            <div class="sg-color-grid">
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #4CD9BA;"></div>
                <div class="sg-color-value">#4CD9BA</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #34B1FC;"></div>
                <div class="sg-color-value">#34B1FC</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #4CD9BA;"></div>
                <div class="sg-color-value">#4CD9BA</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #FFD700;"></div>
                <div class="sg-color-value">#FFD700</div>
              </div>
            </div><!--/.sg-color-grid-->
            <div class="sg-color-grid">
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #0AB58F;"></div>
                <div class="sg-color-value">#0AB58F</div>
              </div>              
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #EDECF0;"></div>
                <div class="sg-color-value">#EDECF0</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #DDDCE0;"></div>
                <div class="sg-color-value">#DDDCE0</div>
              </div>              
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #2C364A;"></div>
                <div class="sg-color-value">#2C364A</div>
              </div>
            </div><!--/.sg-color-grid-->            
            <div class="sg-color-grid">
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #333333;"></div>
                <div class="sg-color-value">#333333</div>
              </div>              
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #4A4A4A;"></div>
                <div class="sg-color-value">#4A4A4A</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #F9F9F9;"></div>
                <div class="sg-color-value">#F9F9F9</div>
              </div>              
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #EEEEEE;"></div>
                <div class="sg-color-value">#EEEEEE</div>
              </div>
            </div><!--/.sg-color-grid-->            
            <div class="sg-color-grid">
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #D8D8D8;"></div>
                <div class="sg-color-value">#D8D8D8</div>
              </div>              
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #C0C0C0;"></div>
                <div class="sg-color-value">#C0C0C0</div>
              </div>
              <div class="sg-color">
                <div class="sg-color-swatch" style="background-color: #838D8F;"></div>
                <div class="sg-color-value">#838D8F</div>
              </div>              
            </div><!--/.sg-color-grid-->
          </div><!--/.sg-colors-->

          <!-- Manually add your fonts here. -->
          <div class="sg-font-stacks sg-section">
            <h2 id="sg-fontStacks" class="sg-h2">Font Stacks</h2>

            <dl class="sg-font-list">
              <dt>Primary Font:</dt>

              <dd style='font-family: "Roboto", Sans-serif'>"Roboto", sans-serif</dd>

            </dl>
            <div class="sg-markup-controls"><a class="sg-btn--top" href="#top">Back to Top</a></div>
          </div><!--/.sg-font-stacks-->
        </div><!--/.sg-info-->

        <?php renderFilesInFolder('markup'); ?>
      </div><!--/.sg-container-->
    </div><!--/.sg-main-->
  </div><!--/.sg-wrapper-->

  <!--[if gt IE 8]><!--><script src="vendor/prisim/prisim.js"></script><!--<![endif]-->
  <script src="js/sg-scripts.js"></script>

  <!-- jQuery -->
  <script src="../js/jquery.js"></script>
  <script src="../js/jquery.mobile.custom.js"></script>
  <!-- Bootstrap Core JavaScript -->
  <script src="../js/bootstrap.min.js"></script>
  <!-- ZIPPY Plugins -->
  <script src="../js/plugins/select/jquery.selectBox.js"></script>
  <script src="../js/plugins/masonry/masonry.pkgd.js"></script>
  <script src="../js/plugins/highcharts/highcharts.js"></script>
  <script src="../js/plugins/highcharts/exporting.js"></script>
  <script src="../js/plugins/datepicker/bootstrap-datepicker.js"></script>
  <script src="../js/bootstrap-table.js"></script>
  <script src="../js/plugins/popup/jquery.magnific-popup.min.js"></script>
  <script src="../js/plugins/cropper/cropper.js"></script>
  <script src="../js/plugins/minicolors/jquery.minicolors.js"></script>
  <script src="../js/plugins/color-thief/color-thief.js"></script>
  <script src="../js/main.js"></script>

</body>
</html>

