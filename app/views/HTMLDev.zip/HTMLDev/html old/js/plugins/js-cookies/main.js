    $(document).ready(function() {
        /*if ($.cookie('profile-progress') == 'yes') {
          $('.profile-progress').addClass('hide-content');
        }*/

        $.cookie('profile-progress', 'yes', {expires: 7 });
    });