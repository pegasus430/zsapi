</div>

<!-- jQuery -->
<script src="js/jquery.js"></script>
<script src="js/jquery.mobile.custom.js"></script>


<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Plugins -->
<script src="js/plugins/select/jquery.selectBox.js"></script>
<script src="js/plugins/masonry/masonry.pkgd.js"></script>
<script src="js/plugins/highcharts/highcharts.js"></script>
<script src="js/plugins/highcharts/exporting.js"></script>
<script src="js/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="js/bootstrap-table.js"></script>
<script src="js/plugins/popup/jquery.magnific-popup.min.js"></script>
<script src="js/plugins/cropper/cropper.js"></script>
<script src="js/plugins/minicolors/jquery.minicolors.js"></script>
<script src="js/plugins/color-thief/color-thief.js"></script>
<script src="js/plugins/hopscotch/hopscotch.js"></script>
<?php echo $showTour; ?>
<script src="js/main.js"></script>


</body>
</html>